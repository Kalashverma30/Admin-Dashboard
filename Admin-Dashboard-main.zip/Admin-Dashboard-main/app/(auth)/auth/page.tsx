import AuthTabs from '@/components/auth/AuthTabs';

const AuthPage = () => {
  return (
    <>
      <AuthTabs />
    </>
  );
};

export default AuthPage;
